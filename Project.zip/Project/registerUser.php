<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Minjor Cineplex | Register</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
<script src="js/cufon-yui.js" type="text/javascript"></script>
<script src="js/cufon-replace.js" type="text/javascript"></script>
<script src="js/Gill_Sans_400.font.js" type="text/javascript"></script>
<script src="js/script.js" type="text/javascript"></script>
<!--[if lt IE 7]>
<script type="text/javascript" src="js/ie_png.js"></script>
<script type="text/javascript">ie_png.fix('.png, .link1 span, .link1');</script>
<link href="css/ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body id="page3">


<?php

$con=mysqli_connect("127.0.0.1","root","","minor");
if (mysqli_connect_errno()){echo "Failed to connect to MySQL: " .
mysqli_connect_error();}

$username= mysqli_real_escape_string($con, $_POST['username']);
$password= mysqli_real_escape_string($con, $_POST['password']);
$name = mysqli_real_escape_string($con, $_POST['name']);
$gender = mysqli_real_escape_string($con, $_POST['gender']);
$age= mysqli_real_escape_string($con, $_POST['age']);
$DOB= mysqli_real_escape_string($con, $_POST['DOB']);
$telephone = mysqli_real_escape_string($con, $_POST['telephone']);
$mail = mysqli_real_escape_string($con, $_POST['mail']);
$address= mysqli_real_escape_string($con, $_POST['address']);

$sql = "INSERT INTO tb_user (username, password, name, gender, age, DOB, telephone, mail, address)
VALUES ('$username','$password','$name','$gender', '$age', '$DOB', '$telephone', '$mail', '$address');";
if (!mysqli_query($con,$sql)) {
die('Error: ' . mysqli_error($con));
}
mysqli_close($con);

?>
<!-- START PAGE SOURCE -->
<div class="tail-top">
  <div class="tail-bottom">
    <div id="main">
      <div id="header">
        <div class="row-1">
          <div class="fleft"><a href="#">Minjor <span>Cineplex</span></a></div>
          <ul>
            <li><a href="myProfile.php">My profile</a></li>
            <li><a href="logout.php">logout</a></li>
          </ul>
        </div>
        <div class="row-2">
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="food&drink.html">Food&Drink</a></li>
            <li><a href="review.html">Review</a></li>
            <li><a href="promotion.html">Promotion</a></li>
          </ul>
        </div>
      </div>
      <div id="content">
        <div class="line-hor"></div>
        <div class="box">
          <div class="border-right">
            <div class="border-left">
              <div class="inner">
                <h3>Registration <span>Successful !!!</span></h3>
                <p>Welcome to Minjor Cineplex! Enjoy the privilege of Membership </p>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
  </div>
</div>
<script type="text/javascript"> Cufon.now(); </script>
<!-- END PAGE SOURCE -->
</body>
</html>