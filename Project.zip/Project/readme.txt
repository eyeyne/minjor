How to run through all the file?
Move the file name “Project” into the “htdocs” of your Xampp
Import “minor.sql” to your database. 
Open your Xampp and turn on the apache server and php. 
Open you web browser and go to http://127.0.0.1/Project/index.html (or http://localhost depend on your computer, directory can chage that is up to your location save file )
Enjoy!

